extends RefCounted
## Shared helpers: persistent settings (user://save.cfg) and button styling.

const SAVE_PATH := "user://save.cfg"
static var _cfg := ConfigFile.new()
static var _loaded := false

static func _ensure() -> void:
	if not _loaded:
		_cfg.load(SAVE_PATH) # a missing file is fine: defaults are used
		_loaded = true

static func get_value(key: String, default_value: Variant) -> Variant:
	_ensure()
	return _cfg.get_value("main", key, default_value)

static func set_value(key: String, value: Variant) -> void:
	_ensure()
	_cfg.set_value("main", key, value)
	_cfg.save(SAVE_PATH)

static func apply_audio() -> void:
	AudioServer.set_bus_mute(0, not bool(get_value("sound", true)))

static func vibrate(ms: int) -> void:
	if bool(get_value("vibration", true)):
		Input.vibrate_handheld(ms)

static func style_button(btn: Button, color: Color, font_size: int = 0) -> void:
	var make := func(c: Color, offset_y: int) -> StyleBoxFlat:
		var sb := StyleBoxFlat.new()
		sb.bg_color = c
		sb.set_corner_radius_all(44)
		sb.set_border_width_all(6)
		sb.border_color = c.lightened(0.35)
		sb.shadow_color = Color(0, 0, 0, 0.35)
		sb.shadow_size = 10
		sb.shadow_offset = Vector2(0, 8)
		sb.content_margin_top = 14 + offset_y
		sb.content_margin_bottom = 14 - offset_y
		sb.content_margin_left = 30
		sb.content_margin_right = 30
		return sb
	btn.add_theme_stylebox_override("normal", make.call(color, 0))
	btn.add_theme_stylebox_override("hover", make.call(color.lightened(0.1), 0))
	btn.add_theme_stylebox_override("pressed", make.call(color.darkened(0.2), 4))
	btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		btn.add_theme_color_override(c, Color.WHITE)
	if font_size > 0:
		btn.add_theme_font_size_override("font_size", font_size)
	btn.focus_mode = Control.FOCUS_NONE
