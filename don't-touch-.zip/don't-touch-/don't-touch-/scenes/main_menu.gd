extends Control

const Utils := preload("res://scenes/utils.gd")
const DIFFICULTIES := ["EASY", "NORMAL", "HARD"]

@onready var single_btn: Button = $VBoxContainer/"1PLAYER"
@onready var two_btn: Button = $VBoxContainer/"2PLAYER"
@onready var diff_btn: Button = $VBoxContainer/DifficultyButton
@onready var sound_btn: Button = $VBoxContainer/SettingsRow/SoundButton
@onready var vib_btn: Button = $VBoxContainer/SettingsRow/VibrationButton
@onready var stats: Label = $Stats

func _ready() -> void:
	Utils.apply_audio()
	Utils.style_button(single_btn, Color("#e0455c"))
	Utils.style_button(two_btn, Color("#3f7fe0"))
	Utils.style_button(diff_btn, Color("#4a4a62"))
	Utils.style_button(sound_btn, Color("#4a4a62"))
	Utils.style_button(vib_btn, Color("#4a4a62"))
	single_btn.pressed.connect(_start_game.bind("single"))
	two_btn.pressed.connect(_start_game.bind("two"))
	diff_btn.pressed.connect(_cycle_difficulty)
	sound_btn.pressed.connect(_toggle.bind("sound"))
	vib_btn.pressed.connect(_toggle.bind("vibration"))
	_refresh()
	_bob($RedHandDeco, 28.0, 2.2)
	_bob($BlueHandDeco, -28.0, 2.6)

func _bob(node: Node2D, amount: float, time: float) -> void:
	var t := create_tween().set_loops()
	t.tween_property(node, "position:y", node.position.y + amount, time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t.tween_property(node, "position:y", node.position.y, time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

func _refresh() -> void:
	diff_btn.text = "CPU: " + DIFFICULTIES[int(Utils.get_value("difficulty", 1))]
	sound_btn.text = "SOUND: " + ("ON" if Utils.get_value("sound", true) else "OFF")
	vib_btn.text = "VIBRATE: " + ("ON" if Utils.get_value("vibration", true) else "OFF")
	var wins := int(Utils.get_value("wins", 0))
	var games := int(Utils.get_value("games", 0))
	stats.text = "VS CPU  —  WINS %d  /  GAMES %d" % [wins, games] if games > 0 else "FIRST TO %d HITS WINS" % 5

func _cycle_difficulty() -> void:
	Utils.set_value("difficulty", (int(Utils.get_value("difficulty", 1)) + 1) % DIFFICULTIES.size())
	_refresh()

func _toggle(key: String) -> void:
	Utils.set_value(key, not bool(Utils.get_value(key, true)))
	Utils.apply_audio()
	Utils.vibrate(30)
	_refresh()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		get_tree().quit()

func _start_game(mode: String) -> void:
	var packed := load("res://scenes/game.tscn") as PackedScene
	var game := packed.instantiate()
	game.setup_mode(mode)
	get_tree().root.add_child(game)
	get_tree().current_scene.queue_free()
	get_tree().current_scene = game
