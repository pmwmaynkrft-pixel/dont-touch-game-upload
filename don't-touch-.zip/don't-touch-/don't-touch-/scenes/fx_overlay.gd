extends Control

var effect_color := Color.WHITE
var effect_center := Vector2.ZERO
var progress := 1.0
var effect_kind := ""
var active_tween: Tween

func play_hit(center: Vector2) -> void:
	_start_effect("hit", center, Color("#ffd166"), 0.42)

func play_dodge(center: Vector2, tint: Color) -> void:
	_start_effect("dodge", center, tint, 0.34)

var streak_up := true

func play_attack(center: Vector2, tint: Color, upward: bool = true) -> void:
	streak_up = upward
	_start_effect("attack", center, tint, 0.30)

func _start_effect(kind: String, center: Vector2, tint: Color, duration: float) -> void:
	if active_tween and active_tween.is_running():
		active_tween.kill()
	effect_kind = kind
	effect_center = center
	effect_color = tint
	progress = 0.0
	queue_redraw()
	active_tween = create_tween()
	active_tween.tween_method(_set_progress, 0.0, 1.0, duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	active_tween.tween_callback(func() -> void:
		effect_kind = ""
		queue_redraw()
	)

func _set_progress(value: float) -> void:
	progress = value
	queue_redraw()

func _draw() -> void:
	if effect_kind.is_empty():
		return
	var fade := 1.0 - progress
	if effect_kind == "attack":
		# vertical speed streaks rushing in the strike direction
		var dir := -1.0 if streak_up else 1.0
		var start_y := size.y if streak_up else 0.0
		for i in range(9):
			var x := size.x * (0.12 + 0.095 * float(i)) + sin(float(i) * 7.3) * 18.0
			var length := 300.0 + 90.0 * float(i % 3)
			var y := start_y + dir * (progress * 1500.0 + float(i % 4) * 120.0)
			draw_line(Vector2(x, y), Vector2(x, y - dir * length), Color(1, 1, 1, 0.35 * fade), 6.0, true)
	var wash := 0.075 if effect_kind == "attack" else (0.16 if effect_kind == "hit" else 0.10)
	draw_rect(Rect2(Vector2.ZERO, size), Color(effect_color.r, effect_color.g, effect_color.b, wash * fade))
	var radius := 22.0 + progress * (160.0 if effect_kind == "hit" else 110.0)
	var width := maxf(2.0, 13.0 * fade)
	draw_arc(effect_center, radius, 0.0, TAU, 56, Color(effect_color.r, effect_color.g, effect_color.b, 0.88 * fade), width, true)
	if effect_kind == "hit":
		draw_arc(effect_center, radius * 0.62, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.72 * fade), maxf(1.0, width * 0.55), true)
	var ray_count := 12 if effect_kind == "hit" else 8
	for i in range(ray_count):
		var angle := TAU * float(i) / float(ray_count) + (progress * 0.22)
		var direction := Vector2(cos(angle), sin(angle))
		var inner := radius * (0.70 if effect_kind == "hit" else 0.82)
		var outer := inner + (54.0 if effect_kind == "hit" else 36.0) * fade
		draw_line(effect_center + direction * inner, effect_center + direction * outer, Color(effect_color.r, effect_color.g, effect_color.b, 0.95 * fade), maxf(2.0, 7.0 * fade), true)
