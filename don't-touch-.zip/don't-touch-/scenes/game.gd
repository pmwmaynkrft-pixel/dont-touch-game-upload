extends Control

enum Phase { READY, ATTACKING, RESOLVING, RESETTING, OVER }
const Utils := preload("res://scenes/utils.gd")

const WIN_SCORE := 5
const IMPACT_TIME := 0.50
const ROUND_PAUSE := 0.48
const RED_BG := Color("#6d2534")
const BLUE_BG := Color("#203d78")
const RED_FX := Color("#ff5b73")
const BLUE_FX := Color("#74baff")
const CENTER := Vector2(550, 1190)
# Dodge can be started at any time by the non-attacking player. The hand only counts as "away"
# while the dodge clip is near its peak, then the hand needs a short rest, so mashing is not safe.
const DODGE_SAFE_FROM := 0.20   # seconds after dodge start when the hand is clear of the collision
const DODGE_SAFE_TO := 0.80
const DODGE_LENGTH := 1.0       # original dodge clip length
const DODGE_COOLDOWN := 0.45    # extra rest after the clip ends
const CHICKEN_AT := 3          # dodges in a row with no attack against you -> hand frozen until you get struck
# CPU tuning per difficulty: chance to dodge, and reaction-time range (seconds).
const AI_LEVELS := [
	{"dodge": 0.35, "react_min": 0.28, "react_max": 0.45},
	{"dodge": 0.62, "react_min": 0.16, "react_max": 0.38},
	{"dodge": 0.82, "react_min": 0.10, "react_max": 0.26},
]

@onready var hand1: Sprite2D = $"hand 1"
@onready var hand2: Sprite2D = $"hand 2"
@onready var attack_player: AnimationPlayer = $AnimationPlayer
@onready var dodge_player: AnimationPlayer = $DodgePlayer
@onready var arena: ColorRect = $Arena
@onready var status: Label = $Status
@onready var score_label: Label = $Score
@onready var fx_overlay: Control = $FxOverlay
@onready var attack_sound: AudioStreamPlayer = $AttackSound
@onready var hit_sound: AudioStreamPlayer = $HitSound
@onready var dodge_sound: AudioStreamPlayer = $DodgeSound
@onready var menu_button: Button = $MenuButton

var attacker := 1
var phase: Phase = Phase.READY
var dodge_started_at := [-100.0, -100.0]  # per player (index 0 = P1), seconds
var dodge_ready_at := [0.0, 0.0]
var dodge_count := [0, 0]      # pre-emptive dodges since the last attack
var frozen := [false, false]   # 'chicken' penalty
var chicken_icons: Array = []  # [player][slot] -> Sprite2D
var chicken_empty_tex: Texture2D
var chicken_full_tex: Texture2D
var bg_pivot: Node2D
var bg_turns := 0
var bg_tween: Tween
var single_player := false
var score := [0, 0]
var round_token := 0
var ai_busy := false
var rng := RandomNumberGenerator.new()
var background_tween: Tween
var hint_tween: Tween
var shake_tween: Tween
var ai_level: Dictionary = AI_LEVELS[1]

var score_labels: Array[Label] = []
var hint_label: Label
var over_layer: Control
var over_title: Label
var over_sub: Label
var rematch_button: Button
var sparks: CPUParticles2D
var chicken_sound: AudioStreamPlayer

func _ready() -> void:
	rng.randomize()
	ai_level = AI_LEVELS[clampi(int(Utils.get_value("difficulty", 1)), 0, AI_LEVELS.size() - 1)]
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	arena.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# Turn/result banner labels stay hidden (requested earlier); the score is shown by the corner numbers.
	status.hide()
	score_label.hide()
	menu_button.z_index = 10
	Utils.style_button(menu_button, Color(0, 0, 0, 0.45), 38)
	_build_background()
	_build_arm_extensions()
	_build_sparks()
	_build_chickens()
	chicken_sound = AudioStreamPlayer.new()
	chicken_sound.stream = load("res://assets/audio/chicken.mp3")
	chicken_sound.volume_db = -4.0
	add_child(chicken_sound)
	_build_score_labels()
	_build_hint()
	_build_game_over()
	_refresh_ui()

func setup_mode(mode: String) -> void:
	single_player = mode == "single"

# ---------- UI construction ----------

func _build_score_labels() -> void:
	# P1 number sits on P1's side; P2's is flipped so it reads correctly for the player across the table.
	for i in 2:
		var l := Label.new()
		l.size = Vector2(170, 150)
		l.pivot_offset = l.size / 2.0
		l.position = Vector2(1080 - 24 - 170, 1250) if i == 0 else Vector2(24, 1000)
		l.rotation = 0.0 if i == 0 else PI
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", 130)
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
		l.add_theme_constant_override("outline_size", 10)
		l.modulate = Color(1, 1, 1, 0.65)
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		l.z_index = 6
		l.text = "0"
		add_child(l)
		score_labels.append(l)

func _build_hint() -> void:
	hint_label = Label.new()
	hint_label.position = Vector2(0, 1100)
	hint_label.size = Vector2(1080, 280)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint_label.add_theme_font_size_override("font_size", 44)
	hint_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	hint_label.add_theme_constant_override("outline_size", 10)
	hint_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_label.z_index = 8
	hint_label.text = "ATTACKER: TAP YOUR SIDE TO SLAP\nDEFENDER: TAP YOUR SIDE TO DODGE (TIME IT!)\n3 DODGES IN A ROW = CHICKEN: HAND FROZEN\nFIRST TO %d HITS WINS" % WIN_SCORE
	add_child(hint_label)
	_show_hint()

func _show_hint() -> void:
	if hint_tween and hint_tween.is_running():
		hint_tween.kill()
	hint_label.modulate.a = 1.0
	hint_tween = create_tween()
	hint_tween.tween_interval(3.0)
	hint_tween.tween_property(hint_label, "modulate:a", 0.0, 0.6)

func _build_game_over() -> void:
	over_layer = Control.new()
	over_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	over_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	over_layer.z_index = 30
	over_layer.hide()
	add_child(over_layer)
	var dim := ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.72)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	over_layer.add_child(dim)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	box.grow_vertical = Control.GROW_DIRECTION_BOTH
	box.add_theme_constant_override("separation", 36)
	over_layer.add_child(box)
	over_title = Label.new()
	over_title.add_theme_font_size_override("font_size", 120)
	over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_title)
	over_sub = Label.new()
	over_sub.add_theme_font_size_override("font_size", 64)
	over_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(over_sub)
	rematch_button = Button.new()
	rematch_button.text = "REMATCH"
	rematch_button.custom_minimum_size = Vector2(760, 170)
	Utils.style_button(rematch_button, Color("#e0455c"), 86)
	rematch_button.pressed.connect(_rematch)
	box.add_child(rematch_button)
	var menu_btn := Button.new()
	menu_btn.text = "MENU"
	menu_btn.custom_minimum_size = Vector2(760, 150)
	Utils.style_button(menu_btn, Color("#4a4a62"), 70)
	menu_btn.pressed.connect(_exit_to_menu)
	box.add_child(menu_btn)


# The arm sprites end in a pointed tip that becomes visible when the hand lunges.
# Stretch a thin band of the arm's own pixels (just before the tip) downward over it, so the
# colours and outline match exactly and the arm always reaches the screen edge.
# Two-colour arena split by a white line: the attacker's half is red, the defender's half is blue.
# When roles swap the whole background turns 180 degrees around the centre.
func _build_background() -> void:
	arena.hide()
	bg_pivot = Node2D.new()
	bg_pivot.position = Vector2(540, 1200)
	add_child(bg_pivot)
	move_child(bg_pivot, 1) # right after the (hidden) Arena, behind the hands
	var parts := [
		[Rect2(-2000, -2600, 4000, 2600), BLUE_BG],   # top half: defender
		[Rect2(-2000, 0, 4000, 2600), RED_BG],        # bottom half: attacker
		[Rect2(-2000, -7, 4000, 14), Color(1, 1, 1, 0.92)], # white divider
	]
	for part in parts:
		var r := ColorRect.new()
		r.position = part[0].position
		r.size = part[0].size
		r.color = part[1]
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bg_pivot.add_child(r)

func _turn_background() -> void:
	var want_even := attacker == 1
	if (bg_turns % 2 == 0) == want_even:
		return
	bg_turns += 1
	if bg_tween and bg_tween.is_running():
		bg_tween.kill()
	bg_tween = create_tween()
	bg_tween.tween_property(bg_pivot, "rotation", PI * float(bg_turns), 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func _build_arm_extensions() -> void:
	_add_arm(hand1, 1666)
	_add_arm(hand2, 1686)

func _add_arm(hand: Sprite2D, band_row: int) -> void:
	var tex := hand.texture
	var ext := Sprite2D.new()
	ext.texture = tex
	ext.region_enabled = true
	ext.region_rect = Rect2(0, band_row, tex.get_width(), 3)
	ext.centered = false
	ext.position = Vector2(-tex.get_width() / 2.0, band_row - tex.get_height() / 2.0)
	ext.scale = Vector2(1.0, 420.0)
	hand.add_child(ext)

func _build_chickens() -> void:
	# A bar of 3 chicken slots per player next to the middle line (P1 bottom-left, P2 top-right, rotated).
	# Blue chicken = empty slot, white chicken = filled slot. The bar is shown only to the defender.
	chicken_empty_tex = load("res://assets/icons/chicken_blue.png")
	chicken_full_tex = load("res://assets/icons/chicken_white.png")
	for i in 2:
		var slots := []
		for k in 3:
			var icon := Sprite2D.new()
			icon.texture = chicken_empty_tex
			icon.scale = Vector2.ONE * (92.0 / icon.texture.get_width())
			if i == 0:
				icon.position = Vector2(72.0 + 104.0 * k, 1385)
			else:
				icon.position = Vector2(1008.0 - 104.0 * k, 1015)
				icon.rotation = PI
			icon.z_index = 7
			add_child(icon)
			slots.append(icon)
		chicken_icons.append(slots)
	_update_chickens(true)

func _update_chickens(instant: bool = false) -> void:
	for i in 2:
		var show_bar: bool = attacker != i + 1
		for k in 3:
			var icon: Sprite2D = chicken_icons[i][k]
			icon.texture = chicken_full_tex if (frozen[i] or k < dodge_count[i]) else chicken_empty_tex
			var target_a := 1.0 if show_bar else 0.0
			if instant:
				icon.modulate.a = target_a
			elif not is_equal_approx(icon.modulate.a, target_a):
				create_tween().tween_property(icon, "modulate:a", target_a, 0.2)
	# frozen hands are tinted cold so the lock is readable
	if frozen[0]:
		hand1.modulate = Color(0.62, 0.78, 1.0)
	if frozen[1]:
		hand2.modulate = Color(0.62, 0.78, 1.0)

func _build_sparks() -> void:
	sparks = CPUParticles2D.new()
	sparks.position = CENTER
	sparks.z_index = 7
	sparks.one_shot = true
	sparks.emitting = false
	sparks.amount = 36
	sparks.lifetime = 0.55
	sparks.explosiveness = 1.0
	sparks.direction = Vector2.UP
	sparks.spread = 180.0
	sparks.initial_velocity_min = 450.0
	sparks.initial_velocity_max = 1000.0
	sparks.damping_min = 600.0
	sparks.damping_max = 900.0
	sparks.scale_amount_min = 10.0
	sparks.scale_amount_max = 22.0
	var g := Gradient.new()
	g.colors = PackedColorArray([Color("#fff6b0"), Color("#ffb347"), Color(1, 0.4, 0.2, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	sparks.color_ramp = g
	add_child(sparks)

func _popup(text: String, color: Color, pos: Vector2) -> void:
	var l := Label.new()
	l.text = text
	l.size = Vector2(700, 140)
	l.position = pos - l.size / 2.0
	l.pivot_offset = l.size / 2.0
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 120)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 20)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.z_index = 9
	l.scale = Vector2(0.3, 0.3)
	l.rotation = rng.randf_range(-0.12, 0.12)
	add_child(l)
	var t := create_tween()
	t.tween_property(l, "scale", Vector2(1.15, 1.15), 0.14).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(l, "scale", Vector2.ONE, 0.08)
	t.tween_interval(0.25)
	t.set_parallel(true)
	t.tween_property(l, "position:y", l.position.y - 90.0, 0.4).set_delay(0.22)
	t.tween_property(l, "modulate:a", 0.0, 0.4).set_delay(0.22)
	t.chain().tween_callback(l.queue_free)

# ---------- Input ----------

func _input(event: InputEvent) -> void:
	# Only real/emulated touches are handled (mouse is emulated as touch via project settings),
	# so a single tap on Android is never processed twice.
	if event is InputEventScreenTouch and event.pressed:
		_handle_tap(event.position)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_exit_to_menu()

func _handle_tap(pos: Vector2) -> void:
	if phase == Phase.RESETTING or phase == Phase.OVER:
		return
	if menu_button.get_global_rect().grow(10.0).has_point(pos):
		return
	var side := 1 if pos.y >= size.y * 0.5 else 2
	if single_player and side == 2:
		return
	if side == attacker:
		if phase == Phase.READY:
			_start_attack()
	elif phase == Phase.READY or phase == Phase.ATTACKING:
		_try_dodge(side)

func _now() -> float:
	return Time.get_ticks_msec() / 1000.0

func _try_dodge(player: int) -> void:
	if frozen[player - 1]:
		return # chicken penalty: hand is stuck until the attacker strikes
	if _now() < dodge_ready_at[player - 1]:
		return # still dodging or resting
	dodge_started_at[player - 1] = _now()
	dodge_ready_at[player - 1] = _now() + DODGE_LENGTH + DODGE_COOLDOWN
	_play_dodge(player)
	if phase == Phase.READY: # dodging with no attack coming counts as fear
		dodge_count[player - 1] += 1
		if dodge_count[player - 1] >= CHICKEN_AT:
			frozen[player - 1] = true
			_popup("CHICKEN!", Color("#ffe27a"), Vector2(550, 1650) if player == 1 else Vector2(550, 560))
			Utils.vibrate(80)
		_update_chickens()

func _is_dodging(player: int) -> bool:
	var elapsed: float = _now() - float(dodge_started_at[player - 1])
	return elapsed >= DODGE_SAFE_FROM and elapsed <= DODGE_SAFE_TO

func _start_attack() -> void:
	if phase != Phase.READY:
		return
	phase = Phase.ATTACKING
	dodge_count = [0, 0]
	attack_player.play("multiply 1" if attacker == 1 else "multiply 2")
	attack_sound.play()
	fx_overlay.play_attack(CENTER, RED_FX if attacker == 1 else BLUE_FX, attacker == 1)
	Utils.vibrate(25)
	_refresh_ui()
	if single_player and attacker == 1:
		_schedule_ai_dodge()
	var token := round_token
	await get_tree().create_timer(IMPACT_TIME).timeout
	if token != round_token or phase != Phase.ATTACKING:
		return
	phase = Phase.RESOLVING
	var defender := 2 if attacker == 1 else 1
	var game_won := false
	var was_dodging := _is_dodging(defender)
	if was_dodging:
		_popup("DODGE!", Color("#ffe27a"), CENTER + Vector2(0, -260))
		attacker = defender
		Utils.vibrate(40)
	else:
		score[attacker - 1] += 1
		hit_sound.play()
		fx_overlay.play_hit(CENTER)
		sparks.restart()
		_popup("SLAP!", RED_FX if attacker == 1 else BLUE_FX, CENTER + Vector2(0, -260))
		Utils.vibrate(120)
		_shake()
		_update_scores(attacker - 1)
		game_won = score[attacker - 1] >= WIN_SCORE
	frozen = [false, false] # the strike (hit or dodged) releases the frozen hand
	dodge_count = [0, 0]
	_refresh_ui()
	await get_tree().create_timer(ROUND_PAUSE).timeout
	if token != round_token:
		return
	_reset_hands()
	if game_won:
		_show_game_over(attacker)
		return
	phase = Phase.READY
	_refresh_ui()
	_schedule_ai_if_needed()

func _play_dodge(player: int) -> void:
	# Uses the original dodge clips on a separate player so they can overlap an attack.
	dodge_player.play("One hand displacement" if player == 1 else "Two hands move")
	chicken_sound.play() # every time a defender moves his hand
	var dodge_center := Vector2(550, 1900) if player == 1 else Vector2(550, 430)
	fx_overlay.play_dodge(dodge_center, RED_FX if player == 1 else BLUE_FX)

func _reset_hands() -> void:
	phase = Phase.RESETTING
	attack_player.stop()
	dodge_player.stop()
	dodge_started_at = [-100.0, -100.0]
	dodge_ready_at = [0.0, 0.0]
	frozen = [false, false]
	dodge_count = [0, 0]
	hand1.position = Vector2(551, 2246)
	hand1.rotation = 0.0
	hand1.scale = Vector2.ONE
	hand2.position = Vector2(550, 185)
	hand2.rotation = PI
	hand2.scale = Vector2.ONE

func _shake() -> void:
	if shake_tween and shake_tween.is_running():
		shake_tween.kill()
	shake_tween = create_tween()
	for i in 4:
		var strength := 22.0 * (1.0 - float(i) / 4.0)
		shake_tween.tween_property(self, "position", Vector2(rng.randf_range(-strength, strength), rng.randf_range(-strength, strength)), 0.04)
	shake_tween.tween_property(self, "position", Vector2.ZERO, 0.04)

func _update_scores(pulse_index: int = -1) -> void:
	for i in 2:
		score_labels[i].text = str(score[i])
	if pulse_index >= 0:
		var l := score_labels[pulse_index]
		var base_rot := l.rotation
		var pulse := create_tween()
		pulse.tween_property(l, "scale", Vector2(1.35, 1.35), 0.10).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		pulse.tween_property(l, "scale", Vector2.ONE, 0.20).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		l.rotation = base_rot

func _refresh_ui() -> void:
	_turn_background()
	_update_scores()
	_pulse_attacker()
	_update_chickens()

# Gentle glow on the hand whose turn it is to attack, so the turn is clear without any text.
func _pulse_attacker() -> void:
	if has_meta("pulse_tween"):
		var old: Tween = get_meta("pulse_tween")
		if old and old.is_running():
			old.kill()
	hand1.modulate = Color.WHITE
	hand2.modulate = Color.WHITE
	if phase != Phase.READY:
		return
	var h: Sprite2D = hand1 if attacker == 1 else hand2
	var t := create_tween().set_loops()
	t.tween_property(h, "modulate", Color(1.3, 1.3, 1.3), 0.45).set_trans(Tween.TRANS_SINE)
	t.tween_property(h, "modulate", Color.WHITE, 0.45).set_trans(Tween.TRANS_SINE)
	set_meta("pulse_tween", t)

# ---------- Game over / rematch ----------

func _show_game_over(winner: int) -> void:
	phase = Phase.OVER
	_pulse_attacker()
	if single_player:
		over_title.text = "YOU WIN!" if winner == 1 else "CPU WINS"
		Utils.set_value("games", int(Utils.get_value("games", 0)) + 1)
		if winner == 1:
			Utils.set_value("wins", int(Utils.get_value("wins", 0)) + 1)
	else:
		over_title.text = "PLAYER %d WINS!" % winner
	over_title.add_theme_color_override("font_color", RED_FX if winner == 1 else BLUE_FX)
	over_sub.text = "%d  —  %d" % [score[0], score[1]]
	Utils.vibrate(200)
	over_layer.modulate.a = 0.0
	over_layer.show()
	create_tween().tween_property(over_layer, "modulate:a", 1.0, 0.25)

func _rematch() -> void:
	round_token += 1 # cancels any pending timers from the previous match
	over_layer.hide()
	score = [0, 0]
	attacker = 1
	ai_busy = false
	_reset_hands()
	phase = Phase.READY
	_refresh_ui()
	_show_hint()

# ---------- CPU ----------

func _schedule_ai_if_needed() -> void:
	if not single_player or attacker != 2 or ai_busy or phase != Phase.READY:
		return
	ai_busy = true
	var token := round_token
	await get_tree().create_timer(rng.randf_range(0.65, 1.25)).timeout
	if token == round_token and phase == Phase.READY and attacker == 2:
		_start_attack()
	ai_busy = false

func _schedule_ai_dodge() -> void:
	var token := round_token
	# The CPU reacts after a delay and deliberately misses some opportunities.
	var will_dodge := rng.randf() < float(ai_level["dodge"])
	await get_tree().create_timer(rng.randf_range(float(ai_level["react_min"]), float(ai_level["react_max"]))).timeout
	if will_dodge and token == round_token and phase == Phase.ATTACKING and attacker == 1:
		_try_dodge(2)

func _exit_to_menu() -> void:
	round_token += 1
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
